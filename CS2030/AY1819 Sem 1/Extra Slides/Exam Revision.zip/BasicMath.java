class BasicMath {
	public static void main(String[] args) {
		int a = 7;
		int b = 5;
		int c = 2;

		// Addition of a and b
		System.out.println(a + b + c);
		// Subtraction of a and b
		System.out.println(a - b + c);
		// Multiplication of a and b
		System.out.println(a * b + c);
		// Division of a by b
		System.out.println(a / b + c);
		// Rejiggeration of a and b
		System.out.println(a * (b + 3) + c);
		// Depression of a and b
		System.out.println((a + b) * (a - b) * (a / b) + c);
	}
}