package cs2030.mystream;

import java.util.Optional;

/**
 * Base class for infinite lazy list.
 * An infinite list is characterized by three traits: whether it is empty, the head value, and the tail list.
 * This base class allows subclasses to implement methods isEmptyImpl, headImpl, tailImpl to specify how to obtain those three traits.
 * Users of infinite lists can call isEmpty, head, tail in any order and any number of times; this class ensures that isEmptyImpl, headImpl, tailImpl are called in that order, and at most once each.
 */
abstract class InfiniteListBase<T> implements InfiniteList<T> {
    
    private Optional<Boolean> isEmptyValue = Optional.empty();
    private Optional<T> headValue = Optional.empty();
    private Optional<InfiniteList<T>> tailValue = Optional.empty();
    
    protected abstract boolean isEmptyImpl();
    protected abstract T headImpl();
    protected abstract InfiniteList<T> tailImpl();
    
    public boolean isEmpty() {
        return (isEmptyValue = Optional.of(isEmptyValue.orElseGet(() -> isEmptyImpl()))).get();
    }
    
    public T head() {
        return (headValue = Optional.of(headValue.orElseGet(() -> {
            isEmpty();
            return headImpl();
        }))).get();
    }
    
    public InfiniteList<T> tail() {
        return (tailValue = Optional.of(tailValue.orElseGet(() -> {
            head();
            return tailImpl();
        }))).get();
    }
}
