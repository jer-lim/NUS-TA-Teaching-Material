package cs2030.mystream;

import java.util.function.Supplier;
import java.util.function.Function;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import java.util.function.BinaryOperator;
import java.util.Optional;

/**
 * Public interface for infinite lazy list.
 * Implementors of this interface must implement isEmpty, head, tail traits for the infinite list, and allow those three methods to be called in any order and any number of times.
 */
public interface InfiniteList<T> {
    
    public boolean isEmpty();
    public T head();
    public InfiniteList<T> tail();

    public static <T> InfiniteList<T> generate(Supplier<T> s) {
        return new InfiniteListBase<T>() {
            protected boolean isEmptyImpl() {
                return false;
            }
            protected T headImpl() {
                return s.get();
            }
            protected InfiniteList<T> tailImpl() {
                return InfiniteList.generate(s);
            }
        };
    }
    
    public static <T> InfiniteList<T> iterateSupplier(Supplier<T> seed, UnaryOperator<T> next) {
        return new InfiniteListBase<T>() {
            T cacheHead;
            protected boolean isEmptyImpl() {
                return false;
            }
            protected T headImpl() {
                return cacheHead = seed.get();
            }
            protected InfiniteList<T> tailImpl() {
                return InfiniteList.iterateSupplier(() -> next.apply(cacheHead), next);
            }
        };
    }

    public static <T> InfiniteList<T> iterate(T seed, UnaryOperator<T> next) {
        return InfiniteList.iterateSupplier(() -> seed, next);
    }

    public default InfiniteList<T> limit(int n) {
        return new InfiniteListBase<T>() {
            protected boolean isEmptyImpl() {
                return n > 0 ? InfiniteList.this.isEmpty() : true;
            }
            protected T headImpl() {
                return InfiniteList.this.head();
            }
            protected InfiniteList<T> tailImpl() {
                return InfiniteList.this.tail().limit(n - 1);
            }
        };
    }
    public default <R> InfiniteList<R> map(Function<? super T, ? extends R> mapper) {
        return new InfiniteListBase<R>() {
            protected boolean isEmptyImpl() {
                return InfiniteList.this.isEmpty();
            }
            protected R headImpl() {
                return mapper.apply(InfiniteList.this.head());
            }
            protected InfiniteList<R> tailImpl() {
                return InfiniteList.this.tail().map(mapper);
            }
        };
    }
    public default InfiniteList<T> filter(Predicate<T> predicate) {
        return new InfiniteListBase<T>() {
            private InfiniteList<T> currlist = InfiniteList.this;
            protected boolean isEmptyImpl() {
                while(!currlist.isEmpty()) {
                    if (predicate.test(currlist.head())) {
                        return false;
                    } else {
                        currlist = currlist.tail();
                    }
                }
                return currlist.isEmpty();
            }
            protected T headImpl() {
                return currlist.head();
            }
            protected InfiniteList<T> tailImpl() {
                return currlist.tail().filter(predicate);
            }
        };
    }
    public default InfiniteList<T> takeWhile(Predicate<T> predicate) {
        return new InfiniteListBase<T>() {
            protected boolean isEmptyImpl() {
                return InfiniteList.this.isEmpty() || !predicate.test(InfiniteList.this.head());
            }
            protected T headImpl() {
                return InfiniteList.this.head();
            }
            protected InfiniteList<T> tailImpl() {
                return InfiniteList.this.tail().takeWhile(predicate);
            }
        };
    }
    public default <U> U reduce(U identity, BiFunction<U, ? super T, U> accumulator) {
        for (InfiniteList<T> currlist = this; !currlist.isEmpty(); currlist = currlist.tail()) {
            identity = accumulator.apply(identity, currlist.head());
        }
        return identity;
    }
    public default Optional<T> reduce(BinaryOperator<T> accumulator) {
        if (this.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(this.tail().reduce(this.head(), accumulator));
    }
    public default long count() {
        long ans = 0;
        for (InfiniteList<T> currlist = this; !currlist.isEmpty(); currlist = currlist.tail()) {
            ++ans;
        }
        return ans;
    }
    public default void forEach(Consumer<T> action) {
        for (InfiniteList<T> currlist = this; !currlist.isEmpty(); currlist = currlist.tail()) {
            action.accept(currlist.head());
        }
    }
    public default Object[] toArray() {
        Object[] arr = new Object[(int)this.count()];
        int index = 0;
        for (InfiniteList<T> currlist = this; !currlist.isEmpty(); currlist = currlist.tail()) {
            arr[index++] = currlist.head();
        }
        return arr;
    }
}
