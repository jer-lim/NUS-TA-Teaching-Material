package cs2030.mystream;

import java.util.ArrayList;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.BinaryOperator;

/**
 * <p>A InfiniteListImpl is a list that supports functional operations
 * generate, iterate, map, filter, reduce, findFirst, limit, count, 
 * zipWith, unzipTo, takeWhile, and forEach.   A InfiniteLIst is 
 * immutable.  It is <i>lazily</i> evaluated. </p>
 * <p>This class is intended to be pseudo-immutable:  
 * Calling any operation on an instance of InfiniteListImpl 
 * shall not affect the return value of any subsequent operation, 
 * as long as all test functions (e.g. predicates, maps) and 
 * supplier/generators are not dependent on one another.</p>
 * 
 * <p>This class guarantees that:</p>
 * <ol>
 * <li>isEmptySupplier is called before headSupplier</li>
 * <li>headSupplier is called before tailSupplier</li>
 * <li>headSupplier and tailSupplier must not be invoked if isEmpty() is true</li>
 * </ol>
 *
 * @author: Bernard Teo
 */
class InfiniteListImpl<T> implements InfiniteList<T> {
  
  /**
   * The supplier of whether the list is empty.
   */
  private Supplier<Boolean> isEmptySupplier;
  /**
   * The supplier of the head.
   */
  private Supplier<T> headSupplier;
  /**
   * The supplier of the tail (rest of the list).
   */
  private Supplier<InfiniteListImpl<T>> tailSupplier;
  
  
  
  /**
   * A cached value of whether the list is empty. 
   */
  private Optional<Boolean> isEmptyValue;
  /**
   * A cached value of the head.
   */
  private Optional<T> headValue;
  /**
   * A cached value of the tail. 
   */
  private Optional<InfiniteListImpl<T>> tailList;
  
  

  /**
   * InfiniteListImpl has a private constructor to prevent the list
   * from being created directly.
   */
  private InfiniteListImpl() { }

  /**
   * A private constructor that takes in three suppliers.
   * @param isEmpty A supplier for whether the list is empty.
   * @param head A supplier for the first element in the list, 
   *     or empty if no more elements.
   * @param tail A supplier for the rest of the elements.
   */
  private InfiniteListImpl(Supplier<Boolean> isEmpty, 
      Supplier<T> head, 
      Supplier<InfiniteListImpl<T>> tail) {
    this.isEmptySupplier = isEmpty;
    this.isEmptyValue = Optional.empty();
    this.headSupplier = head;
    this.headValue = Optional.empty();
    this.tailSupplier = tail;
    this.tailList = Optional.empty();
  }
  
  /**
   * Checks if the list is empty.
   * If we have evaluated that this list is
   * empty, then we returned the cached result.  Otherwise, we evaluate the
   * isEmpty supplier.
   * @return true if the list is empty; false otherwise.
   */
  public boolean isEmpty() {
    Boolean isEmpty = this.isEmptyValue.orElseGet(this.isEmptySupplier);
    this.isEmptyValue = Optional.of(isEmpty);
    return isEmpty;
  }

  /**
   * Return the head of the list.  
   * @return The head of the list.
   */
  public T head() {
    if (this.isEmpty()) {
      throw new IllegalStateException("calling head() on empty list");
    }
    T head = this.headValue.orElseGet(this.headSupplier);
    this.headValue = Optional.of(head);
    return head;
  }

  /**
   * Return the tail of the list, which is another InfiniteListImpl.  
   * If the tail is not evaluated yet, the supplier is called and
   * the value is cached.
   * @return The tail of the list.
   */
  public InfiniteListImpl<T> tail() {
    if (this.isEmpty()) {
      throw new IllegalStateException("calling tail() on empty list");
    }
    head(); // force evaluation of head to satisfy expectations
    InfiniteListImpl<T> list = this.tailList.orElseGet(this.tailSupplier);
    this.tailList = Optional.of(list);
    return list;
  }

  /**
   * Create an empty InfiniteListImpl.
   * @param <T> The type of elements that is supposed to be in this list.
   * @return An empty InfiniteListImpl.
   */
  public static <T> InfiniteListImpl<T> empty() {
    //return new Empty<T>();
    return new InfiniteListImpl<T>(
        () -> true,
        null, 
        null);
  }

  /**
   * Generate an infinite list elements, each is generated with
   * the supplier s.
   * @param <T> The type of elements to generate.
   * @param supply A supplier function to generate the elements.
   * @return A new list generated.
   */
  public static <T> InfiniteListImpl<T> generate(Supplier<? extends T> supply) {
    return new InfiniteListImpl<T>(
        () -> false,
        () -> supply.get(),
        () -> InfiniteListImpl.generate(supply));
  }
  
  /**
   * Generate an infinite list elements, starting with init.get()
   * and next element computed with the {@code next} function.
   * @param <T> The type of elements to generate.
   * @param init The supplier for the first element.
   * @param next A function to generate the next element.
   * @return A new list generated.
   */
  private static <T> InfiniteListImpl<T> iterateSupplier(Supplier<? extends T> init, 
      Function<? super T, ? extends T> next) {
    Wrap<T> initVal = new Wrap<>(null);
    return new InfiniteListImpl<T>(
        () -> false,
        () -> initVal.value = init.get(), 
        () -> InfiniteListImpl.iterateSupplier(() -> next.apply(initVal.value), next));
  }

  /**
   * Generate an infinite list elements, starting with init
   * and next element computed with the {@code next} function.
   * @param <T> The type of elements to generate.
   * @param init The value of the first element.
   * @param next A function to generate the next element.
   * @return A new list generated.
   */
  public static <T> InfiniteListImpl<T> iterate(T init, 
      Function<? super T, ? extends T> next) {
    return new InfiniteListImpl<T>(
        () -> false,
        () -> init, 
        () -> InfiniteListImpl.iterateSupplier(() -> next.apply(init), next));
  }

  /**
   * Return the first element that matches the given predicate, or 
   * Optional.empty() if none of the elements matches.
   * @param predicate A predicate to apply to each element to determine
   *     if it should be returned.
   * @return An Optional object containing either the first element
   *     that matches, or is empty if none of the element matches.
   */
  public Optional<T> findFirst(Predicate<? super T> predicate) {
    InfiniteListImpl<T> list = this;
    while (!list.isEmpty() && !predicate.test(list.head())) {
      list = list.tail();
    }
    return list.isEmpty() ? Optional.empty() : Optional.of(list.head());
  }

  /**
   * Returns a list consisting of the results of applying the given function
   * to the elements of this list.
   * @param <R> The type of elements returned.
   * @param mapper The function to apply to each element.
   * @return The new list.
   */
  public <R> InfiniteListImpl<R> map(Function<? super T, ? extends R> mapper) {
    return new InfiniteListImpl<R>(
        () -> isEmpty(),
        () -> mapper.apply(head()), 
        () -> tail().map(mapper));
  }

  /**
   * Reduce the elements of this stream to a single output, by successively
   * "accumulating" the elements using the given accumulation function.
   *
   * @param <U> The type of the value the list is reduced into.
   * @param identity The identity (initialized the accumulated values)
   * @param accumulator A function that accumulate elements in the stream.
   * @return The accumulated value.
   */
  public <U> U reduce(U identity, 
      BiFunction<? super U, ? super T, ? extends U> accumulator) {
    InfiniteListImpl<T> list = this;
    while (!list.isEmpty()) {
      identity = accumulator.apply(identity, list.head());
      list = list.tail();
    }
    return identity;
  }
  
  public Optional<T> reduce(BinaryOperator<T> accumulator) {
      if (isEmpty()) {
          return Optional.empty();
      }
      return Optional.of(tail().reduce(head(), accumulator));
  }
  
  public void forEach(Consumer<? super T> action) {
    InfiniteListImpl<T> list = this;
    while (!list.isEmpty()) {
      action.accept(list.head());
      list = list.tail();
    }
  }

  /**
   * Truncate the list to up to n elements.  If the list has less than n 
   * elements, then the original list is returned.
   * @param n The number of elements in the truncated list.
   * @return The truncated list.
   */
  public InfiniteListImpl<T> limit(int n) {
    if (n == 0) {
      return InfiniteListImpl.empty();
    }
    return new InfiniteListImpl<T>(
        () -> isEmpty(),
        () -> head(), 
        () -> tail().limit(n - 1));
  }

  /**
   * <p>Return a new list consisting of elements from this list
   * by successively copying the elements, until the predicate
   * becomes false.  All elements in the returned list passed
   * the predicate.</p>
   * @param predicate The predicate to test each element with.
   * @return The new list.
   */
  public InfiniteListImpl<T> takeWhile(Predicate<? super T> predicate) {
    return new InfiniteListImpl<T>(
        () -> isEmpty() || !predicate.test(head()),
        () -> head(), 
        () -> tail().takeWhile(predicate));
  }

  /**
   * Returns a list consisting of the elements of this list that
   * match the given predicate.
   * @param predicate A predicate to apply to each element to 
   *     determine if it should be included
   * @return The new list.
   */
  public InfiniteListImpl<T> filter(Predicate<? super T> predicate) {
    final Wrap<InfiniteListImpl<T>> list = new Wrap<>(this);
    return new InfiniteListImpl<T>(
        () -> {
          while (!list.value.isEmpty() && !predicate.test(list.value.head())) {
            list.value = list.value.tail();
          }
          return list.value.isEmpty();
        },
        () -> list.value.head(), 
        () -> list.value.tail().filter(predicate));
  }

  /**
   * Return the number of elements in this list.
   * @return The number of elements in the list.
   */
  public long count() {
    long counter = 0;
    InfiniteListImpl<T> list = this;
    while (!list.isEmpty()) {
      ++counter;
      list = list.tail();
    }
    return counter;
  }

  /**
   * Return an array containing the elements in the list.
   * @return The array containing the elements in the list.
   */
  public Object[] toArray() {
    Object[] array = new Object[(int)count()];
    InfiniteListImpl<T> list = this;
    for (int index = 0; index < array.length; ++index) {
      array[index] = list.head();
      list = list.tail();
    }
    return array;
  }
}
