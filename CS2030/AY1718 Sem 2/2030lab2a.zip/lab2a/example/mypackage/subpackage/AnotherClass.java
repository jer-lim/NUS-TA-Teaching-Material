package mypackage.subpackage;

class AnotherClass {
	public void doSomething() {
		System.out.println("2) This is in another class");
	}
}