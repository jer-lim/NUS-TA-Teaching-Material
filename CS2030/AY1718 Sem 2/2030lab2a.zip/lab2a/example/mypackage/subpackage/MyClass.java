package mypackage.subpackage;

class MyClass {
	public static void main(String[] args) {
		System.out.println("1) It works!");

		AnotherClass a = new AnotherClass();
		a.doSomething();
	}
}